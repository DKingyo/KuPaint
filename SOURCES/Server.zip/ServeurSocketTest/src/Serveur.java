import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Date;
import java.io.PrintWriter;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class Serveur {
	
	public static void main(String[] zero) {
		
		ServerSocket socketserver = null;
		ArrayList<Client> clients = new ArrayList<>();
    	
    	String str = "{\"pts\":[{\"id\":0,\"x\":5,\"y\":20},"
                + "{\"id\":1,\"x\":5,\"y\":20},"
                + "{\"id\":2,\"x\":25,\"y\":45},"
                + "{\"id\":3,\"x\":55,\"y\":45},"
                + "{\"id\":4,\"x\":50,\"y\":20},"
                + "{\"id\":5,\"x\":35,\"y\":35},"
                + "{\"id\":6,\"x\":5,\"y\":20},"
                + "{\"id\":7,\"x\":5,\"y\":20},"
                + "{\"id\":8,\"x\":60,\"y\":115},"
                + "{\"id\":9,\"x\":60,\"y\":115},"
                + "{\"id\":10,\"x\":60,\"y\":165},"
                + "{\"id\":11,\"x\":100,\"y\":115},"
                + "{\"id\":12,\"x\":100,\"y\":165},"
                + "{\"id\":13,\"x\":85,\"y\":195},"
                + "{\"id\":14,\"x\":60,\"y\":165},"
                + "{\"id\":15,\"x\":100,\"y\":165},"
                + "{\"id\":16,\"x\":60,\"y\":115},"
                + "{\"id\":17,\"x\":100,\"y\":115},"
                + "{\"id\":18,\"x\":100,\"y\":115},"
                + "{\"id\":19,\"x\":0,\"y\":0},]}"
                + "\r\n";
		try {
		
			socketserver = new ServerSocket(9740);
			System.out.println("Le serveur est � l'�coute du port "+socketserver.getLocalPort());

				Socket socketClient = socketserver.accept(); 
				Client client = new Client(socketClient);
				Thread t = new Thread(client);
				t.start();
				clients.add(client);
			
			
			while(true){
				BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
				System.out.println("X? or cmd (i=img)");
				String line0 = br.readLine();
				System.err.println(line0);
				if(line0.equals("i"))
					clients.get(0).paintIMG("D:/Users/blackout/Desktop/out");
				else{
					float x = Float.parseFloat(br.readLine());
					System.out.println("Y?");
					float y = Float.parseFloat(br.readLine());
					System.out.println("Z?");
					float z = Float.parseFloat(br.readLine());
					clients.get(clients.size()-1).sendPoint(x,y,z);
				}
			}
		        
		}catch (IOException e) {
			
			e.printStackTrace();
		}
	}

}
