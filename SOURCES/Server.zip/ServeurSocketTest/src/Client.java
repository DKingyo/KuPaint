import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;


public class Client implements Runnable {

	private Socket socket;
	private BufferedReader in = null;
	private PrintWriter out;
	
	public Client(Socket s){
		this.socket = s;
        try {out = new PrintWriter(this.socket.getOutputStream());} catch (IOException e) {System.err.println(e.getMessage());}
        try {in = new BufferedReader(new InputStreamReader(this.socket.getInputStream()));} catch (IOException e) {System.err.println(e.getMessage());}
        System.out.println("Un z�ro s'est connect� : " + this.socket.getInetAddress());
	}
	@Override
	public void run() {
        String message = null;
    	while(this.socket.isConnected()){
    		try {
				Thread.sleep(10000);
			} catch (InterruptedException e1) {}
            //this.sendPoints();
    		//try {message = in.readLine();} catch (Exception e) {};
    		//System.out.println("> " + message);
    	}
    	
    	try {
        	this.out.close();
        	this.in.close();
			this.socket.close();
	    	System.out.println("Client disconected !");
		} catch (IOException e) {}
	
	}
	public void sendPoints (){
		JSONObject o = new JSONObject();
    	ArrayList<JSONObject> pts1 = new ArrayList<>();
    	pts1.add(new Point(0,0, 0, 10).toJSON());
    	pts1.add(new Point(1,10, 10, 10).toJSON());
    	pts1.add(new Point(2,15, 10, 10).toJSON());
    	pts1.add(new Point(3,15, 0, 10).toJSON());
    	String str = "";
    	/*
    	String str = ""
    			+ "{\"pts\":[{\"id\":0,\"x\":5,\"y\":20,\"z\":30},"
	                + "{\"id\":1,\"x\":5,\"y\":20,\"z\":0},"
	                + "{\"id\":2,\"x\":25,\"y\":45,\"z\":0},"
	                + "{\"id\":3,\"x\":55,\"y\":45,\"z\":0},"
	                + "{\"id\":4,\"x\":50,\"y\":20,\"z\":0},"
	                + "{\"id\":5,\"x\":35,\"y\":35,\"z\":0},"
	                + "{\"id\":6,\"x\":5,\"y\":20,\"z\":0},"
	                + "{\"id\":7,\"x\":5,\"y\":20,\"z\":30},"
	                + "{\"id\":8,\"x\":60,\"y\":115,\"z\":30},"
	                + "{\"id\":9,\"x\":60,\"y\":115,\"z\":0},"
	                + "{\"id\":10,\"x\":60,\"y\":165,\"z\":0},"
	                + "{\"id\":11,\"x\":100,\"y\":115,\"z\":0},"
	                + "{\"id\":12,\"x\":100,\"y\":165,\"z\":0},"
	                + "{\"id\":13,\"x\":85,\"y\":195,\"z\":0},"
	                + "{\"id\":14,\"x\":60,\"y\":165,\"z\":0},"
	                + "{\"id\":15,\"x\":100,\"y\":165,\"z\":0},"
	                + "{\"id\":16,\"x\":60,\"y\":115,\"z\":0},"
	                + "{\"id\":17,\"x\":100,\"y\":115,\"z\":0},"
	                + "{\"id\":18,\"x\":100,\"y\":115,\"z\":30},"
	                + "{\"id\":19,\"x\":0,\"y\":0,\"z\":30},]}"
                + "\r\n";*/

		JSONParser parser = new JSONParser();
		JSONObject json = new JSONObject();
		try {json = (JSONObject) parser.parse(str);} catch (Exception e) {System.err.println(e.getMessage());}
		ArrayList<JSONObject> points = (ArrayList<JSONObject>) json.get("pts");
		
    	//o.put("pts", pts1);
		this.out.println(json.toJSONString());
		this.out.flush();
    	System.err.println("Sending pts:" + json.toJSONString());
	}
	public void sendPoint(float x, float y, float z) {
		JSONObject o = new JSONObject();
    	ArrayList<JSONObject> pts1 = new ArrayList<>();
    	pts1.add(new Point(0,x, y, z).toJSON());
    	o.put("pts", pts1);
		this.out.println(o.toJSONString());
		this.out.flush();
    	//System.err.println("Sending pt:" + o.toJSONString());
		
	}
	public void paintIMG(String url) {

    	String str = "";
    	BufferedReader br;
		try {
			br = new BufferedReader(new FileReader(url));
    	    StringBuilder sb = new StringBuilder();
    	    String line = br.readLine();

    	    while (line != null) {
    	        sb.append(line);
    	        sb.append(System.lineSeparator());
    	        line = br.readLine();
    	    }
    	    str = sb.toString();
    	    br.close();
		} 
		catch (Exception e) {System.err.println(e.getMessage());}

		JSONParser parser = new JSONParser();
		JSONObject json = new JSONObject();
		try {json = (JSONObject) parser.parse(str);} catch (Exception e) {System.err.println(e.getMessage());}
		this.out.println(json.toJSONString());
		this.out.flush();
    	System.err.println("Sending pts:" + json.toJSONString());
	}
	

}
