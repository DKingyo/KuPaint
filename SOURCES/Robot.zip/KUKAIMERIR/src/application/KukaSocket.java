package application;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;
import org.json.simple.*;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;


public class KukaSocket implements Runnable{
	private final String SERVER_IP = "192.168.1.5";
	private final int SERVER_PORT = 9740;
	
	Socket server = null;
	BufferedReader serverRequest = null;
	PrintWriter responseToServer = null;
	
	public KukaSocket(){
		try {
			server = new Socket(SERVER_IP, SERVER_PORT);
			if(server.isConnected())
				System.out.println("[SOCKET] Connected to " + SERVER_IP + ":" + SERVER_PORT + " !");
			serverRequest = new BufferedReader(new InputStreamReader(server.getInputStream()));
			responseToServer = new PrintWriter(server.getOutputStream());
		} catch (Exception e) {System.err.println(e.getMessage());}	
	}
	
	@SuppressWarnings("unchecked")
	public void run() {
		String message;
		JSONObject json = null;
		ArrayList<JSONObject> points;
		
		while(server.isConnected()){
			System.out.println("[SOCKET] Waiting next message ...");
			try {message = serverRequest.readLine();} catch (IOException e) {System.err.println(e.getMessage());break;}

			if(message == null)
				break;
			else if(message.equals("robotInfo"))
				KuPaint.sendRobotInfo();
			else{
				points = formatToPts(message);
				System.err.println(points);
				
				for(JSONObject pt: points)
					KuPaint.stackControlPoint.add(new ControlPoint(Double.parseDouble(pt.get("x").toString()),Double.parseDouble(pt.get("y").toString()),Double.parseDouble(pt.get("z").toString())));
				KuPaint.currentNbPointAdded += points.size();
				System.out.println("[POINTS] Added "+ points.size() + " new point for current drawing.");
			}
		}
		
		try {
			System.out.println("Socket Closed");
		} catch (Exception e) {System.err.println(e.getMessage());}
		
	}

	public void sendJoint(double[] currentJointValue) {
		JSONObject obj = new JSONObject();
		obj.put("jointValue", currentJointValue);
		this.responseToServer.write(obj.toJSONString());
		this.responseToServer.flush();
	}
	public void send(JSONObject objToSend) {
		this.responseToServer.write(objToSend.toJSONString());
		this.responseToServer.flush();
	}
	

	private ArrayList<JSONObject> formatToPts(String str) {
		double width = KuPaint.kuka.getWidth();
		double height = KuPaint.kuka.getHeight();
		ArrayList<JSONObject> ptsOut = new ArrayList<JSONObject>();
		JSONParser parser = new JSONParser();
		JSONObject json = new JSONObject();
		try {json = (JSONObject) parser.parse(str);} catch (Exception e) {System.err.println(e.getMessage());}
		ArrayList<JSONObject> paths = (ArrayList<JSONObject>) json.get("path");
		float drawing_width = Float.parseFloat(json.get("width").toString());
		float drawing_height = Float.parseFloat(json.get("height").toString());
		double scale_width = width / drawing_width;
		double scale_height = height / drawing_height;
		if(scale_width>=scale_height)
			scale_width = scale_height;
		else
			scale_height = scale_width;
		for(JSONObject path: paths){
			ArrayList<JSONObject> ptsPath = (ArrayList<JSONObject>) path.get("pts");
			int i=0;
			for(JSONObject pt: ptsPath){
				if(i == 0 )
					ptsOut.add(formatPoint(new Point(pt).toJSON(), 6,scale_width,scale_height));
				ptsOut.add(formatPoint(new Point(pt).toJSON(), -2,scale_width,scale_height));
				if(i == ptsPath.size()-1)
					ptsOut.add(formatPoint(new Point(pt).toJSON(), 6,scale_width,scale_height));
				i++;
			}
		}
		
		return ptsOut;
	}

	private static JSONObject formatPoint(JSONObject json, int z,double scale_width,double scale_height) {
		json.put("x", (Float.parseFloat(json.get("x").toString()) * (float)scale_width));
		json.put("y", (Float.parseFloat(json.get("y").toString()) * (float)scale_height));
		json.put("z", z);
		return json;
	}


}
