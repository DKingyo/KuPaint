package application;

public class RobotState {
	public double x;
	public double y;
	public double z;
	public int nbOfGotoPointInStack;
	public int currentPointId;
	
	public RobotState(){
		x = 0;
		y = 0;
		z = 0;
		nbOfGotoPointInStack = 0;
		currentPointId = 0;
	}
	
	public RobotState clone(){
		RobotState r = new RobotState();
		r.x = this.x;
		r.y = this.y;
		r.z = this.z;
		r.nbOfGotoPointInStack = this.nbOfGotoPointInStack;
		r.currentPointId = this.currentPointId;
		return r;
	}
	
	public boolean isEqual(RobotState r){
		if( (r.x != this.x) || (r.y != this.y) || (r.z != this.z) || (r.nbOfGotoPointInStack != this.nbOfGotoPointInStack) || (r.currentPointId != this.currentPointId) )
			return false;
		else
			return true;
	}
}
