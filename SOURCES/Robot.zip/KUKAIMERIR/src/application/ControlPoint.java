package application;

public class ControlPoint {
	
	public double x;
	public double y;
	public double z;
	
	ControlPoint()
	{
		x = 0;
		y = 0;
		z = 0;
	}
	
	ControlPoint(double pX, double pY, double pZ)
	{
		x = pX;
		y = pY;
		z = pZ;
	}

	public double distanceTo(ControlPoint targetCP) {
		return (double) Math.sqrt(Math.pow( (this.x - targetCP.x), 2) + Math.pow( (this.y - targetCP.y), 2) + Math.pow( (this.z - targetCP.z), 2));
	}

}
