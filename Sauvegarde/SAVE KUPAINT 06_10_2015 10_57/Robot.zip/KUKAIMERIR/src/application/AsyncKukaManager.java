package application;

import java.util.List;

import com.kuka.generated.ioAccess.MediaFlangeIOGroup;
import com.kuka.roboticsAPI.applicationModel.RoboticsAPIApplication;
import static com.kuka.roboticsAPI.motionModel.BasicMotions.*;

import com.kuka.roboticsAPI.controllerModel.Controller;
import com.kuka.roboticsAPI.controllerModel.sunrise.ISafetyState;
import com.kuka.roboticsAPI.deviceModel.Device;
import com.kuka.roboticsAPI.deviceModel.LBR;
import com.kuka.roboticsAPI.deviceModel.OperationMode;
import com.kuka.roboticsAPI.geometricModel.CartDOF;
import com.kuka.roboticsAPI.geometricModel.Frame;
import com.kuka.roboticsAPI.geometricModel.ObjectFrame;
import com.kuka.roboticsAPI.geometricModel.Tool;
import com.kuka.roboticsAPI.geometricModel.math.Transformation;
import com.kuka.roboticsAPI.motionModel.ErrorHandlingAction;
import com.kuka.roboticsAPI.motionModel.IErrorHandler;
import com.kuka.roboticsAPI.motionModel.IMotion;
import com.kuka.roboticsAPI.motionModel.IMotionContainer;
import com.kuka.roboticsAPI.motionModel.RelativeLIN;
import com.kuka.roboticsAPI.motionModel.Spline;
import com.kuka.roboticsAPI.motionModel.SplineJP;
import com.kuka.roboticsAPI.motionModel.SplineMotion;
import com.kuka.roboticsAPI.motionModel.controlModeModel.CartesianSineImpedanceControlMode;

public class AsyncKukaManager implements Runnable {

	private final int STACK_MAX = 1;
	private final int DISTANCE_MIN_WITH_TARGET = 5;
	private final float TOLERANCE_VALUE = 0.8f;
	public RoboticsAPIApplication app;
	private RelativeLIN[] tabLINControlPoint;
	private ControlPoint targetCP;
	private ControlPoint oldCP;
	private Controller kuka_Sunrise_Cabinet_1;
	private LBR lbr_iiwa_14_R820_1;
	private IMotionContainer currentMotionContainer;
	private List<SplineMotion<?>> currentSplineMotion;
	
	private MediaFlangeIOGroup ioFlange;
	private CartesianSineImpedanceControlMode impedanceControlMode;

	private Tool penTool;
	private ObjectFrame penToolTCP;
	private ObjectFrame paperBase;
	private ObjectFrame paperP1;
	private ObjectFrame paperP2;
	private ObjectFrame paperP3;
	private ObjectFrame paperP0;
	private ObjectFrame nearPaper;
	private ObjectFrame paperApproach;

	private RectangleD frame;
	private double velocity;
	private boolean runThread = true;

	public AsyncKukaManager(KuPaint kuPaint) {
		this.app = kuPaint;
		initialize();
		checkFrame();
	}

	public void initialize() {

		kuka_Sunrise_Cabinet_1 = app.getController("KUKA_Sunrise_Cabinet_1");
		lbr_iiwa_14_R820_1 = (LBR) app.getDevice(kuka_Sunrise_Cabinet_1,
				"LBR_iiwa_14_R820_1");

		ioFlange = new MediaFlangeIOGroup(kuka_Sunrise_Cabinet_1);

		app.getLogger().info("___ KuPaint V1.0-beta - PIR3A - 2015 - M.Ingar ___");

		// On cr�e la compliance pour rendre le bras "mou"
		impedanceControlMode = new CartesianSineImpedanceControlMode();
		impedanceControlMode.parametrize(CartDOF.X).setStiffness(3000);
		impedanceControlMode.parametrize(CartDOF.Y).setStiffness(3000);
		impedanceControlMode.parametrize(CartDOF.Z).setStiffness(3000);

		impedanceControlMode.parametrize(CartDOF.A).setStiffness(200);
		impedanceControlMode.parametrize(CartDOF.B).setStiffness(200);
		impedanceControlMode.parametrize(CartDOF.C).setStiffness(200);

		// On cr�e l'outil stylo, on l'attache au flange et on r�cup�re le point
		// en bout de stylo "penToolTCP"
		penTool = app.getApplicationData().createFromTemplate("penTool");
		penTool.attachTo(lbr_iiwa_14_R820_1.getFlange());
		penToolTCP = penTool.getFrame("/penToolTCP");

		// On charge les points de l'application
		paperBase = app.getApplicationData().getFrame("/Paper");
		paperP1 = app.getApplicationData().getFrame("/Paper/P1");
		paperP2 = app.getApplicationData().getFrame("/Paper/P2");
		paperP3 = app.getApplicationData().getFrame("/Paper/P3");
		paperP0 = app.getApplicationData().getFrame("/Paper/P0");
		nearPaper = app.getApplicationData().getFrame("/Paper/NearPaper0");
		paperApproach = app.getApplicationData().getFrame("/Paper/PaperApproach");
		
		// Control point
		oldCP 		= getToolCP();
		targetCP 	= getToolCP();

		// Set frame
		frame = new RectangleD(0, 0, (paperP1.getY() - paperP0.getY()),(paperP3.getX() - paperP1.getX()));
		app.getLogger().info("[KUKA MANAGER] init success!");
	}

	private void checkFrame() {
		velocity = 0.6;

		ISafetyState currentState = lbr_iiwa_14_R820_1.getSafetyState();
		OperationMode mode = currentState.getOperationMode();

		if (mode == OperationMode.AUT) {
			velocity = 1;
		}

		app.getLogger().info("[CHECKFRAME] Homing progress...");
		lbr_iiwa_14_R820_1.move(ptpHome());
		app.getLogger().info("[CHECKFRAME] Kuka is at Home");
		
		// Approche de la base "Paper" en PTP puis en LIN
		app.getLogger().info("[CHECKFRAME] Move near Paper");
		penToolTCP.move(ptp(paperApproach).setJointVelocityRel(velocity));
		penToolTCP.move(lin(nearPaper).setJointVelocityRel(velocity));
		app.getLogger().info("[CHECKFRAME] MoveTo P0, P1, P2, P3, P0");

		// On bouge en relatif
		// Premier mouvement, on va en de nearPaper1 vers P0
		// On va ensuite � P0, P1, P2 et P3 en sp�cifiant une translation Z nulle
		Spline drawingSpline = new Spline(
				linRel(getTranslationWithSpecifiedZ(nearPaper, paperP0,paperP0.getZ() - nearPaper.getZ() + 10), paperBase)
				//linRel(getTranslationWithSpecifiedZ(paperP0, paperP1,paperP0.getZ()), paperBase), 
				//linRel(getTranslationWithSpecifiedZ(paperP1, paperP2,paperP0.getZ()), paperBase), 
				//linRel(getTranslationWithSpecifiedZ(paperP2, paperP3,paperP0.getZ()), paperBase), 
				//linRel(getTranslationWithSpecifiedZ(paperP3, paperP0,paperP0.getZ()), paperBase)
		);

		penToolTCP.move(drawingSpline.setJointVelocityRel(velocity).setJointAccelerationRel(1).setMode(impedanceControlMode));
		app.getLogger().info("[KUKA MANAGER] checkFrame success!");
	}

	public void run() {
		IErrorHandler errorHandler = new IErrorHandler() {
			@Override
			public ErrorHandlingAction handleError(Device device,IMotionContainer failedContainer,List<IMotionContainer> canceledContainers) {
				// Code which is executed in case of error
				// Close APP !
				return ErrorHandlingAction.EndApplication;
			}
		};
		app.getApplicationControl().registerMoveAsyncErrorHandler(errorHandler);

	
		while (runThread) {
			try {Thread.sleep(10);} catch (InterruptedException e) {}
			if (KuPaint.stackControlPoint.size() == 0 && (this.currentMotionContainer != null && this.currentMotionContainer.getState() != null &&  this.currentMotionContainer.getState().isFinished())) {
				if (!penToolTCP.isCloseTo(nearPaper, DISTANCE_MIN_WITH_TARGET, DISTANCE_MIN_WITH_TARGET)) {
					penToolTCP.move(lin(nearPaper).setJointVelocityRel(velocity));
					ioFlange.setLEDBlue(false);
				} 
			} else {
				//System.err.println(isClosedTo(lbr_iiwa_14_R820_1.getCurrentCartesianPosition(penToolTCP, paperBase), targetCP ));
				if (this.currentMotionContainer == null || this.currentMotionContainer.getState() == null||  this.currentMotionContainer.getState().isFinished() ) {
					oldCP = getToolCP();
					ioFlange.setLEDBlue(true);
					int stackSize = KuPaint.stackControlPoint.size() >= STACK_MAX ? STACK_MAX : KuPaint.stackControlPoint.size();
					KuPaint.currentNbPointDid += stackSize;
					// Tab for Splin
					if(stackSize > 0){
						//System.err.println("StackSize: " + KuPaint.stackControlPoint.size());
						//tabLINControlPoint = new RelativeLIN[stackSize]; // A voir
						int i=0;
						Spline drawingSpline = null;
						/*
						for (i = 0; i < stackSize; i++) {
							targetCP = KuPaint.stackControlPoint.poll();
							if(targetCP != null && isPointInsideFrame(targetCP)){
								// Add point only if the point is inside the frame
								tabLINControlPoint[i] = linRel(getTranslationCP(oldCP, targetCP), paperBase);						
								oldCP = targetCP;
								System.out.println("GNEEEEEEEEEEEe");
							}
						}*/
						//Spline drawingSpline;
						
						targetCP = KuPaint.stackControlPoint.poll();
						if(targetCP != null && isPointInsideFrame(targetCP)){
							drawingSpline = new Spline(linRel(getTranslationCP(oldCP, targetCP), paperBase));	
							oldCP = targetCP;
							i++;
						}
						//drawingSpline = new Spline(tabLINControlPoint); // A voir <<< ICI
						//app.getLogger().info("[DRAWING] Tab made (" + i + ") with " + stackSize + " of stackSize!");
						//System.err.println(tabLINControlPoint);
						// Make Spline
						if(i>0){
							this.currentSplineMotion = drawingSpline.getMotions();
							//app.getLogger().info("[DRAWING] Let's go for " + i + " points.");	
							// moveAsync
							this.currentMotionContainer = penToolTCP.move(drawingSpline.setJointVelocityRel(velocity)
									.setJointAccelerationRel(1)
									.setMode(impedanceControlMode));
							
							//app.getLogger().info("[DRAWING] All " + i + " points are started to draw.");
						}
					}
				}

			}
			// Update robot state
			//TODO		
			
		}
		
		// Back Home
		app.getLogger().info("Homing progress...");
		penToolTCP.move(linRel(getTranslationFromFrame(paperP0, nearPaper),paperBase).setJointVelocityRel(velocity));
		penToolTCP.move(lin(paperApproach).setJointVelocityRel(velocity));
		SplineJP moveBackToHome = new SplineJP(ptpHome());
		lbr_iiwa_14_R820_1.move(moveBackToHome.setJointVelocityRel(velocity));
		ioFlange.setLEDBlue(false);

	}
	
	public int getNbMotionExecuted() {
		if (this.currentMotionContainer != null && this.currentMotionContainer.getState() != null &&  this.currentMotionContainer.getState().isFinished() ) 
			return 1;
		else
			return 0;
	}

	public Controller getController (){
		return this.kuka_Sunrise_Cabinet_1;
	}
	private ControlPoint getToolCP(){
		Frame tmp = lbr_iiwa_14_R820_1.getCurrentCartesianPosition(penToolTCP, paperBase);
		return new ControlPoint( tmp.getX(), tmp.getY(), tmp.getZ());
	}
	public ObjectFrame getPaperBase(){
		return this.paperBase;
	}
	
	public ObjectFrame getPenTool(){
		return this.penToolTCP;
	}

	private Transformation getTranslationWithSpecifiedZ(ObjectFrame frameBefore, ObjectFrame frameDestination, double z) {
		return Transformation.ofTranslation(frameDestination.getX()- frameBefore.getX(),frameDestination.getY() - frameBefore.getY(), z);
	}
	private Transformation getTranslationCP(ControlPoint cpBefore, ControlPoint cpTarget) {
		return Transformation.ofTranslation(cpTarget.x- cpBefore.x,cpTarget.y - cpBefore.y, cpTarget.z - cpBefore.z);
	}
	private Transformation getTranslationFromFrame(ObjectFrame frameBefore,ObjectFrame frameDestination) {
		return Transformation.ofTranslation(frameDestination.getX()- frameBefore.getX(),frameDestination.getY() - frameBefore.getY(),frameDestination.getZ() - frameBefore.getZ());
	}
	private boolean isPointInsideFrame(ControlPoint cp) {
		return ((cp.z >=-10) && frame.isContains(cp.x, cp.y)) ? true:false;
	}

	public int getStackSize() {
		return this.STACK_MAX;
	}

	public double getWidth() {
		return this.frame.width;
	}

	public double getHeight() {
		return this.frame.height;
	}
}
