package application;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class MainClassTest {
	public MainClassTest() {
        
		Socket 	tcpCli = null;	
		BufferedReader 		serverRequest = null;
		PrintWriter	responseToServer;
		
		//Client 
		try {
			tcpCli = new Socket("192.168.1.20", 9740);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			System.exit(0);						
		}
		 
		
		//Format JSON : {"points":[{"id":10,"x":1,"y":2,"Z":0},{"id":11,"x":4,"y":5,"Z":1}]}
		//String str = "{\"points\":[{\"id\":10,\"x\":1,\"y\":2,\"Z\":0},{\"id\":11,\"x\":4,\"y\":5,\"Z\":1}]}";
		
		//Get the client request
		try {
			serverRequest 		= new BufferedReader(new InputStreamReader(tcpCli.getInputStream()));
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	
	    //Start response object
		try {
			responseToServer 	= new PrintWriter(tcpCli.getOutputStream());
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		System.err.println("Ready to read ...");
		//Read socket and parse to JSON
		String str = null;
		try {
			str = serverRequest.readLine();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		System.out.println("Re�u : " + str);
		
		/*
		//Read and parse to JSON
		JSONParser par = new JSONParser();
		try {
			par.parse(str);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		JSONObject o = null;
		
		try {
			o = new JSONObject((Map<?, ?>) par.parse(str));
		} catch (ParseException e) {
			e.printStackTrace();
		}

		@SuppressWarnings("unchecked")
		ArrayList<JSONObject> points = (ArrayList<JSONObject>) o.get("points");
		
		Iterator<JSONObject> it = null;
		
		if(points == null) 
		{
			System.out.println("toto");			
		} 
		else
		{
			it = points.iterator();
						
			while (it.hasNext()) {
				JSONObject obj = it.next();			
				System.out.println(obj.get("id"));
			}
		}
		*/
		 
	
		
	}

}
