package application;

public class Vector2 {

	public double x;
	public double y;
	
	Vector2()
	{
		x = 0;
		y = 0;
		
	}
	
	Vector2(double pX, double pY)
	{
		x = pX;
		y = pY;
	}	
}
