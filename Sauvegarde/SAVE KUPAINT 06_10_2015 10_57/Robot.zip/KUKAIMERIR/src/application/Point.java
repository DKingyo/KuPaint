package application;
import org.json.simple.JSONObject;


public class Point {
	private float x;
	private float y;

	public Point (String x, String y){
		this.x = Float.parseFloat(x);
		this.y = Float.parseFloat(y);
	}
	public Point (float x, float y){
		this.x = x;
		this.y = y;
	}

	public Point(Point point) {
		this.x = point.getX();
		this.y = point.getY();
	}
	public Point(JSONObject jsonObject) {
		this.x = Float.parseFloat(jsonObject.get("x").toString());
		this.y = Float.parseFloat(jsonObject.get("y").toString());
	}
	public Point(Point point, Point offset) {
		this.x = point.getX() + offset.getX();
		this.y = point.getY() + offset.getY();
	}
	public Float getX(){
		return this.x;
	}
	public Float getY(){
		return this.y;
	}
	public void setX(float X){
		this.x = x;
	}
	public void setY(float Y){
		this.y = y;
	}
	
	public float distanceTo(Point p){
		return (float) Math.sqrt(Math.pow( (this.x-p.getX()), 2) + Math.pow( (this.y-p.getY()), 2));
		
	}
	
	public JSONObject toJSON(){
		JSONObject o = new JSONObject();
		o.put("x", this.x);
		o.put("y", this.y);
		return o;
	}
	public String toString(){
		return "["+this.x+":"+this.y+"]";
	}
	
	
}
