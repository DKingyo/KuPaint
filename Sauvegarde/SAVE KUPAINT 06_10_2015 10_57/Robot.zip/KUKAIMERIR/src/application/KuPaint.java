package application;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Stack;
import java.util.concurrent.ConcurrentLinkedQueue;
import org.json.simple.JSONObject;
import com.kuka.roboticsAPI.applicationModel.RoboticsAPIApplication;

public class KuPaint extends RoboticsAPIApplication {
	public static ConcurrentLinkedQueue<ControlPoint> stackControlPoint;
	public static ArrayList<ArrayList<JSONObject>> receptedWork;
	public static double[] currentJointValue;
	public static int currentNbPointAdded = 0;
	public static int currentNbPointDid = 0;
	private float lastPourcentWork = 0f;
	public static RobotState robotState; 
	public static KukaSocket socket;
	public static AsyncKukaManager kuka;
		
	public static void main(String[] args) {
		System.out.println("welcome");
		KuPaint app = new KuPaint();
		app.runApplication();
	}
	
	public void initialize() {
		
		KuPaint.receptedWork = new ArrayList<ArrayList<JSONObject>>();
		KuPaint.currentNbPointDid = 0;
		KuPaint.stackControlPoint = new ConcurrentLinkedQueue<ControlPoint>();
		KuPaint.robotState = new RobotState();
		
		this.kuka = new AsyncKukaManager(this);
		Thread u = new Thread(kuka);
		u.start();
		System.out.println("[INIT] AsyncKukaManager ready and running.");
		
		KuPaint.socket = new KukaSocket();
		Thread v = new Thread(socket);
		v.start();
		
	}
	
	public void run() {
		while(true){
			try {Thread.sleep(100);} catch (InterruptedException e) {}
			computePourcentWork();
			//updateJoint();
		}
	}
	
	private void updateJoint() {
		//if()
		//KuPaint.currentJointValue = this.kuka.getController().getCommandedJointPosition().get();
		//KuPaint.1socket.sendJoint(KuPaint.currentJointValue);
	}

	private void computePourcentWork (){
		if(KuPaint.currentNbPointAdded == 0){return;};
		float currentPourcentWork = Math.round(( (KuPaint.currentNbPointDid-this.kuka.getStackSize() - this.kuka.getNbMotionExecuted()) * 100 / KuPaint.currentNbPointAdded)*10)/10;
		if(currentPourcentWork != this.lastPourcentWork){
			this.lastPourcentWork = currentPourcentWork;
			System.out.println("[WORK PROGRESS] Current %:" + this.lastPourcentWork);
		}
	}

	public static void close() {
		System.exit(0);
	}
}
