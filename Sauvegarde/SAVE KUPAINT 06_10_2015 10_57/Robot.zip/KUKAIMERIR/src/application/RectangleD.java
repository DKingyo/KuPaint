package application;

public class RectangleD {
	
	public double x;
	public double y;
	public double width;
	public double height;
	
	public RectangleD()
	{
		this.x = 0;
		this.y = 0;
		this.width = 0;
		this.height = 0;		
	}
	
	public RectangleD(double pX, double pY, double pHeight, double pWidth)
	{
		this.x = pX;
		this.y = pY;
		this.width = pWidth;
		this.height = pHeight;
	}
	
	public boolean isContains(double pointX, double pointY)
	{	       
		if ( (pointX >= this.x) && (pointX <= (this.x + this.width)) &&
				(pointY >= this.y) && (pointY <= (this.y + this.height)))
		{
			return true;
		}			
		else
		{
			return false;
		}			
	}

}
